# TheMauler — FIXES-RECENT

Date: 2026-10-25  
Status: **PLAN ONLY — USER REVIEW REQUIRED BEFORE IMPLEMENTATION**

## Purpose

This file is the staged update and reliability plan for TheMauler. It is designed to update the Go,
Wails, frontend, provider, and agent-reliability layers without overwriting user settings or mixing
unrelated migrations. No code, dependency, profile, provider-secret, or live-setting change is
authorized until the user approves the relevant phase.

## User settings that must remain unchanged

Preserve the active files under `~/.config/mauler` and their existing values, including:

- The InferenceBridge endpoint and port `8804`.
- All local/LAN choices. Do not replace the configured host, port, or provider with a repository
  default such as port 8800.
- Profiles, model choices, context, thinking, MTP, KV-cache, default autonomy, task routing, toolset,
  workspaces, shell/WSL selection, time/call budgets, Telegram/audio, logging, and UI layout.
- The OpenRouter one-task boost behaviour and provider secret precedence.
- Existing unrestricted profiles and engagement workflows.

Security settings such as secret redaction, confirmations, root execution, or tool scope may be
recommended below, but they require a separate explicit decision and must not be silently changed
during a dependency upgrade.

## Current verified baseline

- Repository branch: `main`.
- Last committed baseline observed: `8ebe2f8aea1180b7b0895da5f4decad8fb32b6a8`.
- Working tree at audit time: 39 modified/staged entries and 9 untracked entries. Treat them as user
  work.
- `go test ./... -count=1` passed.
- `go vet ./...` passed.
- Frontend type-drift check and production build passed. The main frontend chunk was approximately
  617 KB and is a later code-splitting candidate.
- `govulncheck ./...` found zero reachable vulnerable symbols. It still identified advisory-bearing
  imported/module versions that should be upgraded.
- The current live Agent Eval promotion gate is not complete: the last recorded UI Gate 1 was
  11/12, so pass^5 remains locked.

## Immediate issues

### M1 — Protect the current work before dependency changes

1. Create a checkpoint branch or verified archive.
2. Separate existing source changes from generated bindings/build output.
3. Record current settings/profile schema hashes, Go/Wails/Node versions, active provider/model,
   runtime lock, and the full green test commands without storing secrets.
4. Ensure every dependency phase has a single-command rollback to its prior `go.mod`, `go.sum`,
   `package.json`, lockfile, generated bindings, and Wails build.

### M2 — Fix the critical frontend dependency advisory

Mauler's frontend overrides DOMPurify to 3.4.12 through Monaco. The production audit reported one
critical and one moderate finding.

Plan:

1. Update the explicit DOMPurify override to 3.4.17 or a newer patched compatible 3.4.x.
2. Keep Monaco 0.56 initially; do not combine the sanitizer fix with Monaco's breaking ESM changes.
3. Run `npm audit --omit=dev`, type-drift, editor-tab tests, TypeScript, production build, and manual
   untrusted Markdown/HTML/SVG/Monaco-hover probes.
4. Consider Monaco 0.57 in a separate later phase with editor, diff, LSP, tab, persistence, and
   generated-binding verification.

Acceptance: no high/critical production advisory and no model/tool/file content can create an
executable WebView payload.

### M3 — Repair InferenceBridge authentication

InferenceBridge's live server requires an API key. Mauler's provider secret store currently has an
OpenRouter entry but no `inference-bridge` entry, and the provider's `api_key_env` is empty.

Plan after explicit approval:

1. Store the existing InferenceBridge credential using Mauler's provider-secret API, or name an
   environment variable in the provider profile.
2. Never write the credential to `profiles.toml`, React state, logs, prompts, exported evidence, or
   this repository.
3. Add/retain a presence-only diagnostic.
4. Verify authenticated models, chat, streaming, cancellation, model load and image paths.

Do not solve this by disabling InferenceBridge authentication.

### M4 — Repair the unrestricted model identity

The saved unrestricted profile references `Qwen3.8-27B-Uncensored-Q4_K_M.gguf`, while the installed
working artifact uses the exact RVN filename and the runtime lock already records that override.

Plan:

1. Select the exact installed RVN GGUF in the profile or introduce a tested stable alias in
   InferenceBridge.
2. Validate the exact template, thinking, preserved thinking, context, MTP x2, required tool call,
   argument repair, cancellation, and reload behaviour.
3. Keep aligned Qwen3.8 as the reliable daily profile and RVN as the deliberate unrestricted lane.
4. Update Bug Bounty/Ops profile references only after the exact RVN route passes.

### M5 — Review logging and host privileges separately

Current live settings include secret redaction disabled, full response/tool logging, an unrestricted
toolset, long run/tool budgets, and a Kali/WSL root shell. These are not dependency-upgrade fields.

Recommended separate review:

- Enable secret redaction while retaining model capability.
- Keep the unrestricted toolset only for explicit profiles; use semantic narrowing and the existing
  scope/control-plane gates for normal work.
- Use a non-root WSL user for routine runs and a disposable/root profile for exceptional work.
- Keep the 200-call/1800-second budget only for deliberate long operations; use a lower normal
  budget to bound loops.
- Define ledger rotation/retention and sanitize existing logs only after the user chooses what must
  be retained.

No item in this subsection may be changed as a side effect of the update phases.

## Dependency update phases

### Phase M-A — Go security patch within the current release

Update the toolchain directive from Go 1.26.3 to Go 1.26.10 first. This is the smallest security
update and should precede a Go 1.27 migration.

Gate:

```powershell
go test ./... -count=1
go vet ./...
go test -race ./internal/app ./internal/tools -count=1
npm run --prefix frontend build
wails build
```

### Phase M-B — Wails 2.17 security update

Update Wails 2.12.0 to 2.17.0. The release hardens `wails dev` against cross-origin IPC WebSocket
access and DNS rebinding and removes a PowerShell notification fallback.

Review and test:

- Generated bindings and the 406-field settings model remain in sync.
- App startup/shutdown, WebView2 IPC, notification behaviour, window/layout persistence, dialogs,
  file operations, terminal sessions, browser workflows, Telegram/audio startup ownership, and
  production packaging.
- `wails dev` is tested from the normal loopback workflow without adding broad allowed hosts.
- Do not migrate to Wails 3 while it is beta.

### Phase M-C — Direct Go module security/maintenance updates

Upgrade direct modules in small groups, not with one blanket `go get -u`:

1. Security group: `golang.org/x/crypto` 0.51.0 to current tested 0.58.x and
   `golang.org/x/text` 0.37.0 to current tested 0.43.x. `govulncheck` found no reachable vulnerable
   calls, but the old versions contain advisory-bearing packages/modules.
2. Browser group: `chromedp` 0.15.1 to 0.21.x plus a compatible `cdproto`. Run native browser,
   cancellation, evidence, download, promptware, and supervised pass^k tests.
3. Storage group: `modernc.org/sqlite` 1.50.1 to 1.61.x. Run migrations against copied databases,
   WAL/restart/recovery, ledger, memory, sessions, and concurrency/race tests.
4. Utility group: TOML 1.4 to 1.6 and the PDF extractor to a reviewed commit, with settings
   round-trip and bounded-file fixtures.

Commit and verify each group independently. Do not update unrelated indirect modules merely because
a newer tag exists.

### Phase M-D — Go 1.27.3 candidate

After all previous phases are stable, update the `go` directive/toolchain to 1.27.3 on a dedicated
branch. Run the complete backend, race, frontend, native Wails, browser, provider, settings migration,
and agent reliability gates. Do not combine it with Wails or module-version changes.

### Phase M-E — Frontend maintenance and code splitting

Only after the sanitizer fix:

- Evaluate Monaco 0.57 and `@monaco-editor/react` compatibility separately.
- Split heavy workbench/editor routes so Monaco is not in the initial path when unused.
- Preserve resizable panels, tabs, generated bindings, editor state, LSP, diffs, and narrow layouts.
- Keep the current React/Vite/TypeScript versions when already current unless a concrete advisory or
  fix justifies movement.

## Reliability completion plan

The app's deterministic gates are strong, but live model promotion is unfinished.

Required order:

1. Make one deliberate model/profile/control change at a time.
2. Run fresh UI Gate 1 and achieve 12/12.
3. Run five independently clean rounds: 60/60 total attempts. Any failed round is not pass^5.
4. Run the rebuilt-native M1 lifecycle-race and M3 scoped-repair/handoff UI smokes.
5. Run a supervised local-model browser pass^k.
6. Complete Telegram/audio live smokes and prove remote delivery matches the final desktop answer.
7. Preserve exact model, profile, settings, binary, scenario, and evidence hashes in the result.

Do not call the selected profile unattended-reliable before this evidence exists.

## Remaining product work

- Add bounded OCR for scanned PDFs and bounded 7z extraction before optional embeddings.
- Complete multi-size native screenshot acceptance.
- Finish richer immutable browser evidence promotion/review.
- Add provider/auth diagnostics that never expose secret values.
- Reconcile the stale localhost smoke target that still uses port 8800, while preserving the live
  user endpoint at port 8804.
- Add `govulncheck ./...` and production `npm audit` to CI. Keep Go tests/vet/race and frontend/native
  builds as required gates.

## Cross-project coordination

Required order:

1. Checkpoint all three dirty repositories.
2. Fix InferenceBridge's critical frontend advisory while retaining the current API/config.
3. Repair Mauler's InferenceBridge secret and exact model identity after approval.
4. Apply Mauler's DOMPurify fix.
5. Move through Go 1.26.10, Wails 2.17, direct module groups, then Go 1.27.3.
6. Qualify against the working InferenceBridge runtime before testing any llama.cpp candidate.
7. Run Gate 1 and pass^5 only on the final exact binary/runtime/profile combination.

## Required final verification

```powershell
go test ./... -count=1
go vet ./...
go test -race ./internal/app ./internal/tools -count=1
go run golang.org/x/vuln/cmd/govulncheck@latest ./...
npm ci --prefix frontend
npm audit --omit=dev --prefix frontend
npm run --prefix frontend check-types
npm run --prefix frontend test:editor-tabs
npm run --prefix frontend build
wails build
```

Repository-wide frontend lint remains a documented non-gate until its generated/legacy baseline is
cleaned up; do not falsely report it green.

## Explicitly out of scope until separately approved

- Changing port 8804, host/bind choice, provider order, local/LAN behaviour, or model defaults.
- Rewriting existing profiles/settings with fresh defaults.
- Enabling/disabling secret redaction, confirmations, root shell, unrestricted tools, logging, or
  budgets as a hidden migration.
- Deleting configs, backups, state databases, run evidence, complete models, or rollback builds.
- Wails 3, blanket `go get -u`, or a combined Go/Wails/browser/storage migration.

## Approval checklist

- [ ] Checkpoint/backup method approved.
- [ ] DOMPurify patch approved.
- [ ] InferenceBridge credential repair approved.
- [ ] Exact RVN model identity approved.
- [ ] Optional logging/privilege changes reviewed separately.
- [ ] Go 1.26.10 phase approved.
- [ ] Wails 2.17 phase approved.
- [ ] Direct-module group order approved.
- [ ] Go 1.27.3 candidate approved.
- [ ] Live Gate 1/pass^5 window approved.

