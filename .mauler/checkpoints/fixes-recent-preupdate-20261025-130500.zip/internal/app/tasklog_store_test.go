package app

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"mauler/internal/controlplane"
	"mauler/internal/store"
)

func TestTaskRunDBSaveLoadAndReplace(t *testing.T) {
	db, err := store.Open(filepath.Join(t.TempDir(), "state.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	run := TaskRun{
		ID:                "task-1",
		Generation:        1_800_000_000_001,
		ConversationEpoch: 7,
		ParentRunID:       "task-parent",
		Prompt:            "do thing",
		Mode:              "Builder",
		Profile:           "qwen",
		Model:             "model",
		ClaimantID:        "channel:telegram:chat-1:msg-9",
		ClaimantAlias:     "operator",
		Origin:            "telegram",
		Status:            "done",
		State:             "done",
		StartedAt:         "2026-06-15T10:00:00+01:00",
		EndedAt:           "2026-06-15T10:01:00+01:00",
		Summary:           "first",
		FinalizedArtifacts: []FinalizedArtifact{{
			Path: "missing-report.md", SHA256: strings.Repeat("a", 64), Size: 12,
			RunID: "task-1", Generation: 1_800_000_000_001, ConversationEpoch: 7,
			EvidenceID: "file_sha256:missing-report.md:" + strings.Repeat("a", 64), FinalizedAt: "2026-06-15T10:01:00Z",
		}},
		Tools:  []TaskToolEvent{{Name: "shell", Status: "done", Input: "{}", Result: "ok", Timestamp: "2026-06-15T10:00:30+01:00"}},
		Events: []TaskRunEvent{{Kind: "state", Message: "testing", Timestamp: "2026-06-15T10:00:20+01:00"}},
	}
	contract, err := controlplane.NewTaskContract(controlplane.ContractInput{
		RunID: run.ID, Objective: run.Prompt, WorkspaceRoot: t.TempDir(),
		CreatedAt: time.Date(2026, 7, 15, 10, 0, 0, 0, time.UTC),
	})
	if err != nil {
		t.Fatal(err)
	}
	control, err := controlplane.NewMachineState(contract, time.Date(2026, 7, 15, 10, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	run.Contract, run.Control = &contract, &control
	if err := saveTaskRunDB(db, run, nil); err != nil {
		t.Fatal(err)
	}
	run.Summary = "replaced"
	run.Tools = append(run.Tools, TaskToolEvent{Name: "write", Status: "done", Timestamp: "2026-06-15T10:00:40+01:00"})
	if err := saveTaskRunDB(db, run, nil); err != nil {
		t.Fatal(err)
	}

	runs, err := loadTaskRunsDB(db)
	if err != nil {
		t.Fatal(err)
	}
	if len(runs) != 1 {
		t.Fatalf("runs = %d, want 1", len(runs))
	}
	if runs[0].Summary != "replaced" || len(runs[0].Tools) != 2 || len(runs[0].Events) != 1 {
		t.Fatalf("unexpected loaded run: %#v", runs[0])
	}
	if runs[0].ClaimantID != run.ClaimantID || runs[0].ClaimantAlias != run.ClaimantAlias || runs[0].Origin != run.Origin {
		t.Fatalf("claimant provenance did not round-trip: %#v", runs[0])
	}
	if runs[0].Generation != run.Generation {
		t.Fatalf("run generation did not round-trip: got %d want %d", runs[0].Generation, run.Generation)
	}
	if runs[0].ConversationEpoch != run.ConversationEpoch {
		t.Fatalf("conversation epoch did not round-trip: got %d want %d", runs[0].ConversationEpoch, run.ConversationEpoch)
	}
	if runs[0].ParentRunID != run.ParentRunID {
		t.Fatalf("parent run id did not round-trip: got %q want %q", runs[0].ParentRunID, run.ParentRunID)
	}
	if len(runs[0].FinalizedArtifacts) != 1 || runs[0].FinalizedArtifacts[0].SHA256 != run.FinalizedArtifacts[0].SHA256 || runs[0].FinalizedArtifacts[0].Fresh || runs[0].FinalizedArtifacts[0].Freshness != "missing" {
		t.Fatalf("finalized artifacts did not round-trip with derived freshness: %#v", runs[0].FinalizedArtifacts)
	}
	if runs[0].Contract == nil || runs[0].Control == nil || runs[0].Contract.Digest != contract.Digest || runs[0].Control.Phase != controlplane.PhaseIntake {
		t.Fatalf("control plane did not round-trip: %#v", runs[0])
	}
}

func TestStartTaskRunIDsAreUniqueWithinOneSecond(t *testing.T) {
	first := startTaskRun("one", "Auto", "profile", "model")
	second := startTaskRun("two", "Auto", "profile", "model")
	if first.ID == second.ID {
		t.Fatalf("sequential task runs reused id %q", first.ID)
	}
	if second.Generation <= first.Generation {
		t.Fatalf("sequential task generations did not advance: first=%d second=%d", first.Generation, second.Generation)
	}
}

func TestTaskRunDBRetentionAndClear(t *testing.T) {
	db, err := store.Open(filepath.Join(t.TempDir(), "state.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	cfg := &settingsLoggingConfig{enabled: true, maxRuns: 2}
	for _, run := range []TaskRun{
		{ID: "old", StartedAt: "2026-06-15T09:00:00+01:00", Status: "done"},
		{ID: "mid", StartedAt: "2026-06-15T10:00:00+01:00", Status: "done"},
		{ID: "new", StartedAt: "2026-06-15T11:00:00+01:00", Status: "done"},
	} {
		if err := saveTaskRunDB(db, run, cfg); err != nil {
			t.Fatal(err)
		}
	}
	runs, err := loadTaskRunsDB(db)
	if err != nil {
		t.Fatal(err)
	}
	if len(runs) != 2 || runs[0].ID != "new" || runs[1].ID != "mid" {
		t.Fatalf("retained runs = %#v", runs)
	}
	if err := clearTaskRunsDB(db); err != nil {
		t.Fatal(err)
	}
	runs, err = loadTaskRunsDB(db)
	if err != nil {
		t.Fatal(err)
	}
	if len(runs) != 0 {
		t.Fatalf("clear left runs: %#v", runs)
	}
}

func TestClearTaskRunsAlsoClearsLegacyJSON(t *testing.T) {
	t.Setenv("MAULER_CONFIG_DIR", t.TempDir())
	db, err := store.Open(filepath.Join(t.TempDir(), "state.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	app := &App{db: db}
	legacy := []TaskRun{{
		ID:        "task-legacy",
		Prompt:    "old run",
		Status:    "stopped",
		StartedAt: "2026-06-15T12:00:00+01:00",
	}}
	if err := saveTaskRuns(legacy); err != nil {
		t.Fatalf("save legacy json: %v", err)
	}
	if err := migrateTaskRunsJSONToDB(db); err != nil {
		t.Fatalf("migrate legacy json: %v", err)
	}
	if err := app.ClearTaskRuns(); err != nil {
		t.Fatalf("clear task runs: %v", err)
	}
	jsonRuns, err := loadTaskRuns()
	if err != nil {
		t.Fatalf("load legacy json: %v", err)
	}
	if len(jsonRuns) != 0 {
		t.Fatalf("legacy task-runs json retained stale runs: %#v", jsonRuns)
	}
	freshDB, err := store.Open(filepath.Join(t.TempDir(), "fresh-state.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer freshDB.Close()
	if err := migrateTaskRunsJSONToDB(freshDB); err != nil {
		t.Fatalf("fresh migration: %v", err)
	}
	runs, err := loadTaskRunsDB(freshDB)
	if err != nil {
		t.Fatal(err)
	}
	if len(runs) != 0 {
		t.Fatalf("stale task-runs json was re-imported: %#v", runs)
	}
}

func TestTaskRunJSONExportImportUsesSQLiteStore(t *testing.T) {
	db, err := store.Open(filepath.Join(t.TempDir(), "state.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	app := &App{db: db}
	original := []TaskRun{
		{
			ID:        "task-export",
			Prompt:    "export me",
			Status:    "done",
			StartedAt: "2026-06-15T12:00:00+01:00",
			Tools:     []TaskToolEvent{{Name: "shell", Status: "done", Result: "ok"}},
			Events:    []TaskRunEvent{{Kind: "state", Message: "done"}},
		},
	}
	if err := replaceTaskRunsDB(db, original); err != nil {
		t.Fatal(err)
	}
	exported, err := app.ExportTaskRunsJSON()
	if err != nil {
		t.Fatal(err)
	}
	if err := app.ClearTaskRuns(); err != nil {
		t.Fatal(err)
	}
	if count, err := app.ImportTaskRunsJSON(exported); err != nil || count != 1 {
		t.Fatalf("import count/error = %d/%v", count, err)
	}
	runs, err := app.ListTaskRuns()
	if err != nil {
		t.Fatal(err)
	}
	if len(runs) != 1 || runs[0].ID != "task-export" || len(runs[0].Tools) != 1 || len(runs[0].Events) != 1 {
		t.Fatalf("imported runs = %#v", runs)
	}
}
