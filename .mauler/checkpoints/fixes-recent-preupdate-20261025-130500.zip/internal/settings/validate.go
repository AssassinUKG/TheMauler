package settings

import (
	"fmt"
	"strings"
)

const (
	defaultCompactionAt     = 0.85
	defaultMaxToolCalls     = 200
	maxToolCallsLimit       = 2000
	defaultCtxTokens        = 8192
	defaultMaxTokens        = 2048
	defaultKVCachePrecision = "f16"
)

// Validate clamps dangerous or out-of-range settings to safe values. It never
// errors because settings load should always produce a usable configuration.
func (s *Settings) Validate() []string {
	if s == nil {
		return nil
	}
	var adjustments []string
	switch strings.ToLower(strings.TrimSpace(s.Tools.TaskRoutingMode)) {
	case "", "auto":
		s.Tools.TaskRoutingMode = "auto"
	case "selected":
		s.Tools.TaskRoutingMode = "selected"
	default:
		adjustments = append(adjustments, fmt.Sprintf("tools.task_routing_mode reset from %q to auto", s.Tools.TaskRoutingMode))
		s.Tools.TaskRoutingMode = "auto"
	}
	if s.Context.CompactionAt <= 0 || s.Context.CompactionAt >= 1 {
		adjustments = append(adjustments, fmt.Sprintf("context.compaction_at clamped from %v to %.2f", s.Context.CompactionAt, defaultCompactionAt))
		s.Context.CompactionAt = defaultCompactionAt
	}
	if s.Agents.MaxToolCalls <= 0 {
		adjustments = append(adjustments, fmt.Sprintf("agents.max_tool_calls clamped from %d to %d", s.Agents.MaxToolCalls, defaultMaxToolCalls))
		s.Agents.MaxToolCalls = defaultMaxToolCalls
	} else if s.Agents.MaxToolCalls > maxToolCallsLimit {
		adjustments = append(adjustments, fmt.Sprintf("agents.max_tool_calls clamped from %d to %d", s.Agents.MaxToolCalls, maxToolCallsLimit))
		s.Agents.MaxToolCalls = maxToolCallsLimit
	}
	if s.Agents.MaxRunSeconds < 0 {
		adjustments = append(adjustments, fmt.Sprintf("agents.max_run_seconds clamped from %d to 0", s.Agents.MaxRunSeconds))
		s.Agents.MaxRunSeconds = 0
	}
	if s.Agents.ReviewLoop.MaxReviewCycles < 0 {
		adjustments = append(adjustments, fmt.Sprintf("agents.review_loop.max_review_cycles clamped from %d to 0", s.Agents.ReviewLoop.MaxReviewCycles))
		s.Agents.ReviewLoop.MaxReviewCycles = 0
	} else if s.Agents.ReviewLoop.MaxReviewCycles > 5 {
		adjustments = append(adjustments, fmt.Sprintf("agents.review_loop.max_review_cycles clamped from %d to 5", s.Agents.ReviewLoop.MaxReviewCycles))
		s.Agents.ReviewLoop.MaxReviewCycles = 5
	}
	if s.Agents.ReviewLoop.VerifyTimeoutSec <= 0 {
		adjustments = append(adjustments, fmt.Sprintf("agents.review_loop.verify_timeout_sec clamped from %d to 120", s.Agents.ReviewLoop.VerifyTimeoutSec))
		s.Agents.ReviewLoop.VerifyTimeoutSec = 120
	}
	if s.Agents.ReviewLoop.ReviewerMaxTools <= 0 {
		adjustments = append(adjustments, fmt.Sprintf("agents.review_loop.reviewer_max_tools clamped from %d to 15", s.Agents.ReviewLoop.ReviewerMaxTools))
		s.Agents.ReviewLoop.ReviewerMaxTools = 15
	} else if s.Agents.ReviewLoop.ReviewerMaxTools > 40 {
		adjustments = append(adjustments, fmt.Sprintf("agents.review_loop.reviewer_max_tools clamped from %d to 40", s.Agents.ReviewLoop.ReviewerMaxTools))
		s.Agents.ReviewLoop.ReviewerMaxTools = 40
	}
	if s.Telegram.ProgressIntervalS < 3 {
		adjustments = append(adjustments, fmt.Sprintf("telegram.progress_interval_s clamped from %d to 3", s.Telegram.ProgressIntervalS))
		s.Telegram.ProgressIntervalS = 3
	}
	if s.Audio.Mode != "push_to_talk" && s.Audio.Mode != "open_mic" {
		s.Audio.Mode = "push_to_talk"
	}
	if s.Audio.STTEngine == "" {
		s.Audio.STTEngine = "whisper"
	}
	if s.Audio.TTSEngine == "" {
		s.Audio.TTSEngine = "auto"
	}
	if s.Audio.Voice == "" {
		s.Audio.Voice = "af_heart"
	}
	if s.Audio.Speed < 0.8 || s.Audio.Speed > 1.4 {
		adjustments = append(adjustments, fmt.Sprintf("audio.speed clamped from %.2f to 1.00", s.Audio.Speed))
		s.Audio.Speed = 1
	}
	if s.Audio.VADThreshold <= 0 || s.Audio.VADThreshold >= 1 {
		s.Audio.VADThreshold = 0.55
	}
	if s.Audio.ClauseMinChars < 16 || s.Audio.ClauseMinChars > 240 {
		s.Audio.ClauseMinChars = 36
	}
	switch strings.ToLower(strings.TrimSpace(s.Agents.ReasoningEffort)) {
	case "", "auto":
		s.Agents.ReasoningEffort = "auto"
	case "none", "minimal", "low", "medium", "high", "xhigh":
		s.Agents.ReasoningEffort = strings.ToLower(strings.TrimSpace(s.Agents.ReasoningEffort))
	default:
		adjustments = append(adjustments, fmt.Sprintf("agents.reasoning_effort reset from %q to auto", s.Agents.ReasoningEffort))
		s.Agents.ReasoningEffort = "auto"
	}
	switch strings.ToLower(strings.TrimSpace(s.Agents.ThinkingMode)) {
	case "", "auto":
		s.Agents.ThinkingMode = "auto"
	case "on", "off":
		s.Agents.ThinkingMode = strings.ToLower(strings.TrimSpace(s.Agents.ThinkingMode))
	default:
		adjustments = append(adjustments, fmt.Sprintf("agents.thinking_mode reset from %q to auto", s.Agents.ThinkingMode))
		s.Agents.ThinkingMode = "auto"
	}
	switch strings.ToLower(strings.TrimSpace(s.Agents.DefaultConversationMode)) {
	case "", "adaptive":
		s.Agents.DefaultConversationMode = "adaptive"
	case "direct", "agent":
		s.Agents.DefaultConversationMode = strings.ToLower(strings.TrimSpace(s.Agents.DefaultConversationMode))
	default:
		adjustments = append(adjustments, fmt.Sprintf("agents.default_conversation_mode reset from %q to adaptive", s.Agents.DefaultConversationMode))
		s.Agents.DefaultConversationMode = "adaptive"
	}
	return adjustments
}

// Validate clamps profile generation settings and records profiles that point at
// unknown providers. Unknown providers are left intact so Doctor can surface the
// wiring problem without destroying user intent.
func (pf *ProfilesFile) Validate() []string {
	if pf == nil {
		return nil
	}
	var adjustments []string
	for name, profile := range pf.Profiles {
		label := name
		if profile.Name != "" {
			label = profile.Name
		}
		if profile.CtxTokens <= 0 {
			adjustments = append(adjustments, fmt.Sprintf("profiles.%s.ctx_tokens clamped from %d to %d", label, profile.CtxTokens, defaultCtxTokens))
			profile.CtxTokens = defaultCtxTokens
		}
		if profile.Provider != "" && pf.Providers != nil {
			if _, ok := pf.Providers[profile.Provider]; !ok {
				adjustments = append(adjustments, fmt.Sprintf("profiles.%s.provider references unknown provider %q", label, profile.Provider))
			}
		}
		if pf.profileUsesLlamaCpp(profile) {
			precision, cacheTypeK, cacheTypeV := ResolveKVCacheConfig(
				profile.KVCachePrecision,
				profile.KVCacheTypeK,
				profile.KVCacheTypeV,
			)
			if profile.KVCachePrecision != precision || profile.KVCacheTypeK != cacheTypeK || profile.KVCacheTypeV != cacheTypeV {
				adjustments = append(adjustments, fmt.Sprintf(
					"profiles.%s.kv_cache normalized to %s (K %s, V %s)",
					label,
					precision,
					displayKVCacheType(cacheTypeK),
					displayKVCacheType(cacheTypeV),
				))
				profile.KVCachePrecision = precision
				profile.KVCacheTypeK = cacheTypeK
				profile.KVCacheTypeV = cacheTypeV
			}
		}
		profile.ThinkGeneral, adjustments = validateGenerationParams(label, "thinking_general", profile.CtxTokens, profile.ThinkGeneral, adjustments)
		profile.ThinkCoding, adjustments = validateGenerationParams(label, "thinking_coding", profile.CtxTokens, profile.ThinkCoding, adjustments)
		profile.NoThink, adjustments = validateGenerationParams(label, "nothinking", profile.CtxTokens, profile.NoThink, adjustments)
		pf.Profiles[name] = profile
	}
	return adjustments
}

func (pf *ProfilesFile) profileUsesLlamaCpp(profile Profile) bool {
	backend := strings.TrimSpace(profile.Backend)
	if provider, ok := pf.Providers[profile.Provider]; ok {
		backend = strings.TrimSpace(provider.Backend)
	}
	return strings.EqualFold(backend, "llamacpp")
}

// ResolveKVCacheConfig returns the exact InferenceBridge launch values for a
// profile. FP16 is the quality-first fallback. Automatic mode intentionally
// leaves the K/V types empty so InferenceBridge can use its backend default.
func ResolveKVCacheConfig(precision, cacheTypeK, cacheTypeV string) (string, string, string) {
	precision = normalizeKVCachePrecision(precision)
	switch precision {
	case "auto":
		return precision, "", ""
	case "custom":
		return precision, normalizeKVCacheType(cacheTypeK), normalizeKVCacheType(cacheTypeV)
	default:
		return precision, precision, precision
	}
}

func normalizeKVCachePrecision(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "auto":
		return "auto"
	case "f16", "fp16":
		return "f16"
	case "bf16", "bfloat16":
		return "bf16"
	case "q8", "q8_0":
		return "q8_0"
	case "q4", "q4_0":
		return "q4_0"
	case "custom":
		return "custom"
	default:
		return defaultKVCachePrecision
	}
}

func normalizeKVCacheType(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "f16", "fp16":
		return "f16"
	case "bf16", "bfloat16":
		return "bf16"
	case "q8", "q8_0":
		return "q8_0"
	case "q4", "q4_0":
		return "q4_0"
	default:
		return defaultKVCachePrecision
	}
}

func displayKVCacheType(value string) string {
	if value == "" {
		return "backend default"
	}
	return value
}

func validateGenerationParams(profileName, preset string, ctxTokens int, params GenerationParams, adjustments []string) (GenerationParams, []string) {
	prefix := fmt.Sprintf("profiles.%s.%s", profileName, preset)
	if params.MaxTokens <= 0 {
		adjustments = append(adjustments, fmt.Sprintf("%s.max_tokens clamped from %d to %d", prefix, params.MaxTokens, defaultMaxTokens))
		params.MaxTokens = defaultMaxTokens
	}
	if ctxTokens > 0 {
		halfCtx := ctxTokens / 2
		if halfCtx < 1 {
			halfCtx = 1
		}
		if params.MaxTokens > halfCtx {
			adjustments = append(adjustments, fmt.Sprintf("%s.max_tokens clamped from %d to %d", prefix, params.MaxTokens, halfCtx))
			params.MaxTokens = halfCtx
		}
	}
	if params.Temperature < 0 {
		adjustments = append(adjustments, fmt.Sprintf("%s.temperature clamped from %v to 0", prefix, params.Temperature))
		params.Temperature = 0
	} else if params.Temperature > 2 {
		adjustments = append(adjustments, fmt.Sprintf("%s.temperature clamped from %v to 2", prefix, params.Temperature))
		params.Temperature = 2
	}
	if params.TopP <= 0 {
		adjustments = append(adjustments, fmt.Sprintf("%s.top_p clamped from %v to 1", prefix, params.TopP))
		params.TopP = 1
	} else if params.TopP > 1 {
		adjustments = append(adjustments, fmt.Sprintf("%s.top_p clamped from %v to 1", prefix, params.TopP))
		params.TopP = 1
	}
	if params.TopK < 0 {
		adjustments = append(adjustments, fmt.Sprintf("%s.top_k clamped from %d to 0", prefix, params.TopK))
		params.TopK = 0
	}
	if params.MinP < 0 {
		adjustments = append(adjustments, fmt.Sprintf("%s.min_p clamped from %v to 0", prefix, params.MinP))
		params.MinP = 0
	} else if params.MinP > 1 {
		adjustments = append(adjustments, fmt.Sprintf("%s.min_p clamped from %v to 1", prefix, params.MinP))
		params.MinP = 1
	}
	return params, adjustments
}
